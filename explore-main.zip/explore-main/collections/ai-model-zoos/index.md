---
items:
 - tensorflow/models
 - Theano/Theano
 - BVLC/caffe
 - facebookarchive/models
 - apache/mxnet
 - deeplearning4j/deeplearning4j
 - theonesud/Pytorch-Model-Zoo
 - Lasagne/Recipes
 - albertomontesg/keras-model-zoo
 - hindupuravinash/the-gan-zoo
 - likedan/Awesome-CoreML-Models
 - microsoft/CNTK
display_name: Model Zoos of machine and deep learning technologies
created_by: alanbraz
---
Model Zoo is a common way that open source frameworks and companies organize their machine learning and deep learning models.
