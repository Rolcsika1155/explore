---
items:
 - LeCoupa/awesome-cheatsheets
 - detailyang/awesome-cheatsheet
 - FavioVazquez/ds-cheatsheets
 - gto76/python-cheatsheet
 - wilfredinni/python-cheatsheet
 - ihebski/DefaultCreds-cheat-sheet
 - tldr-pages/tldr
 - cheat/cheat
 - srsudar/eg
 - gnebbia/kb
 - denisidoro/navi
display_name: Useful cheatsheets
created_by: Luois45
---
A list of useful cheat sheets for various programming languages and commands.
