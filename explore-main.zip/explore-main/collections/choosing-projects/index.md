---
items:
 - rust-lang/rust
 - Homebrew/brew
 - https://www.youtube.com/embed/dSl_qnWO104
 - public-apis/public-apis
 - SerenityOS/serenity
 - komodorio/helm-dashboard
 - cloudquery/cloudquery
 - Ileriayo/markdown-badges
 - mem0ai/mem0
 - Codecademy/docs
 - open-sauced/guestbook 
 - firstcontributions/first-contributions
display_name: How to choose (and contribute to) your first open source project
created_by: kytrinyx
---
New to open source? Here’s how to find projects that need help and start making impactful contributions.
