---
items:
 - Slackadays/Clipboard
 - p0deje/Maccy
 - hluk/CopyQ
 - TermiT/Flycut
 - Clipy/Clipy
display_name: Clipboard Managers
created_by: SpongeJohnSquareLennon
image: clipboard-managers.png
---
Leave more room in your brain with this list of awesome clipboard managers.
