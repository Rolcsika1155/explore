---
items:
 - twbs/bootstrap
 - foundation/foundation-sites
 - jgthms/bulma
 - uikit/uikit
 - Semantic-Org/Semantic-UI
 - Dogfalo/materialize
 - pure-css/pure
 - tailwindlabs/tailwindcss
 - Trendyol/baklava
display_name: CSS Frameworks
created_by: krishdevdb
---
A CSS framework is a set of css classes that allow you to create your website with little to no new css code.
