---
items:
 - alisaifee/coredis
 - ziishaned/dumper.js
 - wajahatkarim3/EasyFlipView
 - alisaifee/flask-limiter
 - ziishaned/learn-regex
 - sarfraznawaz2005/whatspup
display_name: Dil Dil Pakistan
created_by: alisaifee
image: dil-dil-pakistan.png
---

Open source projects built in Pakistan or by individuals or groups with :pakistan: in their :heart:.

