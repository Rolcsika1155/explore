---
items:
 - PixelVision8/PixelVision8
 - https://www.youtube.com/watch?v=UKVNmHCxwk4
 - LIKO-12/LIKO-12
 - nesbox/TIC-80
 - pico-8/awesome-PICO-8
 - paladin-t/b8
 - kitao/pyxel
 - le-doux/bitsy
 - morgan3d/quadplay
 - emmachase/Riko4
display_name: Fantasy Consoles
created_by: leereilly
---
Fantasy consoles are mini game engines or virtual machines that simulate 8-bit computers and consoles from yesteryear. They force developers to work within constraints on color palettes, sound channels, resolution, memory, etc. Very popular in the retrogaming and game jam scenes. Try one out - they're super fun!
