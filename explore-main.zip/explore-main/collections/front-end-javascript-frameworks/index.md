---
items:
 - solidjs/solid
 - marko-js/marko
 - MithrilJS/mithril.js
 - angular/angular
 - emberjs/ember.js
 - knockout/knockout
 - tastejs/todomvc
 - spine/spine
 - vuejs/vue
 - Polymer/polymer
 - facebook/react
 - finom/seemple
 - aurelia/framework
 - optimizely/nuclear-js
 - jashkenas/backbone
 - dojo/dojo
 - jorgebucaran/hyperapp
 - riot/riot
 - Daemonite/material
 - lit/lit
 - aurelia/aurelia
 - sveltejs/svelte
 - neomjs/neo
 - preactjs/preact
 - ionic-team/stencil
 - withastro/astro
 - QwikDev/qwik
 - vercel/next.js
 - gatsbyjs/gatsby
 - sveltejs/kit
 - refinedev/refine

display_name: Front-end JavaScript frameworks
created_by: jonrohan
---
While the number of ways to organize JavaScript is almost infinite, here are some tools that help you build single-page applications.
