---
items:
 - docker/dockercraft
 - minefold/hubot-minecraft
 - leereilly/hubot-minecraft-skin
 - overviewer/Minecraft-Overviewer
 - cuberite/cuberite
 - pmmp/PocketMine-MP
 - msmhq/msm
 - essentials/Essentials
 - VazkiiMods/Botania
 - MightyPirates/OpenComputers
 - PrismarineJS/mineflayer
 - EngineHub/WorldEdit
 - SpigotMC/BungeeCord
 - walterhiggins/ScriptCraft
 - MinecraftForge/MinecraftForge
 - ddevault/TrueCraft
 - MachineMuse/MachineMusePowersuits
 - micdoodle8/Galacticraft
 - Bukkit/Bukkit
 - GlowstoneMC/Glowstone
 - MovingBlocks/Terasology
 - Zerite/CraftLib
 - PaperMC/Paper
 - CaffeineMC/sodium-fabric
 - FabricMC/fabric
 - lambda-client/lambda/
 - nerdsinspace/nocom-explanation
display_name: Hacking Minecraft
created_by: leereilly
image: hacking-minecraft.png
---
Minecraft is a game about building blocks, but it doesn’t end there. Take Minecraft further with some of the projects below, or dive into the code mines and hammer your own!
