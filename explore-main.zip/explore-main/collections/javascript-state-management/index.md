---
items:
 - effector/effector
 - mobxjs/mobx
 - reduxjs/redux
 - Yomguithereal/baobab
 - immerjs/immer
 - statelyai/xstate
 - cerebral/cerebral
 - storeon/storeon
 - artalar/reatom
 - persevie/statemanjs
display_name: JavaScript State Management Tools
created_by: lestad
---
Framework agnostic libraries to manage state in JavaScript applications.
