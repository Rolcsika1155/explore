---
items:
 - spatie/laravel-permission
 - laravel-mix/laravel-mix
 - filamentphp/filament
 - bavix/laravel-wallet
 - mpociot/teamwork
 - hammerstonedev/fast-paginate
 - opcodesio/log-viewer
 - devtical/laravel-helpers
 - thephpleague/flysystem-aws-s3-v3
 - getsentry/sentry-laravel
 - romanzipp/Laravel-Queue-Monitor
display_name: Laravel Libraries
created_by: ezhasyafaat
---
Collection of useful libraries for Laravel applications.
