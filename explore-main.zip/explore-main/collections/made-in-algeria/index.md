---
items:
 - 01walid/dzlibs
 - othmanus/algeria-cities
 - Alfanous-team/alfanous
 - GitHubAlgeria/pyIslam
 - mohsenuss91/AlgerianAdministrativeDivision
 - Alfanous-team/alfanous
 - idurar/idurar-erp-crm
 - linuxscout/mishkal
 - linuxscout/pyarabic
 - linuxscout/tashaphyne
 - Hamz-a/frida-android-helper
 - SofianeHamlaoui/Lockdoor-Framework
 - assem-ch/django-jet-reboot
 - assem-ch/arabicstemmer
 - 01walid/sloughi
 - OpenDZ/timgad
 - aissat/easy_localization
 - open-minds/awesome-openminds-team
 - linuxscout/alyahmor
 - linuxscout/yarob
 - linuxscout/ghalatawi
 - linuxscout/qalsadi
 - linuxscout/mishkal
display_name: Made in Algeria
created_by: the-dijkstra
image: made-in-algeria.png
---
Open source projects built in or receiving significant contributions from Algeria 🇩🇿