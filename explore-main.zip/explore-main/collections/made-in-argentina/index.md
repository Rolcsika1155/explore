---
items:
  - code-hike/codehike
  - mgonto/restangular
  - play-with-docker/play-with-docker
  - redis/jedis
  - Mango/slideout
  - pazguille/offline-first
  - Aerolab/midnight.js
  - cazala/synaptic
  - cazala/coin-hive
  - decentraland/marketplace
  - dropwizard/dropwizard
  - andresriancho/w3af
display_name: Made in Argentina
created_by: marcosnils
image: made-in-argentina.png
---

Open source projects built in or receiving significant contributions from Argentina :argentina:
