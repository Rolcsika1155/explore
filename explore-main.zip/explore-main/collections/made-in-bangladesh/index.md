---
items:
 - adar2378/pin_code_fields
 - Agontuk/react-native-geolocation-service
 - alamkanak/Android-Week-View
 - sohelamin/crud-generator
 - sohelamin/laravel-admin
 - halfo/lambda-mod-zsh-theme
 - LordAmit/Brightness
 - mmahmoodictbd/production-ready-microservices-starter
 - mugli/Avro-Keyboard
 - nahid/gohttp
 - nahid/jsonq
 - nahid/talk
 - neurobin/shc
 - nuhil/bangladesh-geocode
 - OpenBangla/OpenBangla-Keyboard
 - proshoumma/react-native-off-canvas-menu
 - s1s1ty/py-jsonq
 - safwanrahman/django-webpush
 - sagorbrur/bnlp
 - sarim/ibus-avro
 - Shafin098/pakhi-bhasha
 - tareq1988/wordpress-settings-api-class
 - tareq1988/wp-eloquent
 - thedevsaddam/gojsonq
 - thedevsaddam/govalidator
 - thesabbir/simple-line-icons
 - usmanhalalit/charisma
 - usmanhalalit/laracsv
 - boss-net/license-checker
 - bangladeshos/bangladeshos

display_name: Made in Bangladesh
created_by: kuttumiah
image: made-in-bangladesh.png
---
Open source projects built in or receiving significant contributions from Bangladesh :bangladesh:
