---
items:
  - clappr/clappr
  - devhubapp/devhub
  - dracula/dracula-theme
  - elixir-lang/elixir
  - ellisonleao/magictools
  - felipefialho/frontend-challenges
  - go-task/task
  - heartcombo/devise
  - htop-dev/htop/
  - lua/lua
  - RocketChat/Rocket.Chat
  - tsuru/tsuru
  - goreleaser/goreleaser
  - Universidade-Livre/ciencia-da-computacao
  - cuducos/minha-receita
  - kvnol/aprenda-frontend
  - felipeorlando/aprenda-rubyonrails
  - BrasilAPI/BrasilAPI
  - alt-art/commit
  - backend-br/desafios
  - backend-br/vagas
  - gittogethers/octogatosconf22
  - github/brasil
  - raphamorim/rio
  - avelino/awesome-go
  - okfn-brasil/querido-diario
  - Purple-Stock/open-erp
  - thiagobarbosa/quorum-api
  - pgmodeler/pgmodeler
  - alshedivat/al-folio
  - george-gca/multi-language-al-folio
  - levxyca/diciotech
  - turicas/brasil.io
  - react-brasil/empresas-que-usam-react-no-brasil
  - bacen/pix-api
  - Abacatinhos/eventos-tech-brasil
  
display_name: Made in Brazil
created_by: caarlos0
image: made-in-brazil.png
---
Open source projects built in or receiving significant contributions from Brazil :brazil:
