---
items:
 - alibaba/arthas
 - alibaba/p3c
 - alibaba/druid
 - alibaba/fastjson
 - alibaba/flutter-go
 - Tencent/weui
 - Tencent/wepy
 - Tencent/tinker
 - Tencent/mars
 - Tencent/weui-wxss
 - Tencent/vConsole
 - Tencent/QMUI_Android
 - Tencent/MMKV
 - Tencent/omi
 - Tencent/ncnn
 - Tencent/VasSonic
 - Tencent/rapidjson
 - Tencent/APIJSON
 - baidu/amis
 - baidu/san
 - baidu/uid-generator
 - CHINA-JD/presto
 - ElemeFE/element
 - ElemeFE/mint-ui
 - ElemeFE/node-interview
 - ElemeFE/v-charts
 - apolloconfig/apollo
 - NetEase/pomelo
 - Meituan-Dianping/mpvue
 - Meituan-Dianping/walle
 - dianping/cat
 - XiaoMi/soar
 - XiaoMi/mace
 - didi/DoKit
 - didi/cube-ui
 - didi/chameleon
 - didi/VirtualAPK
 - bilibili/ijkplayer
 - bilibili/flv.js
 - bilibili/DanmakuFlameMaster
display_name: Made in China
created_by: renfei
image: made-in-china.png
---
Open source projects built in or receiving significant contributions from China :cn:
