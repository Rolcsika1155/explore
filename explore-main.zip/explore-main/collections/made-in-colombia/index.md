---
items:
  - jofpin/trape
  - juliandavidmr/sails-inverse-model
  - tomasr/viasfora
  - jofpin/brutto
  - jahirfiquitiva/Blueprint
  - guilleiguaran/fakeredis
  - jahirfiquitiva/Frames
  - Edu4rdSHL/unimap
  - Edu4rdSHL/tor-router
  - MauricioRobayo/nextjs-google-analytics
  - OCA/l10n-colombia
  - caroso1222/notyf
  - DiegoRBaquero/BTorrent
  - suarezafelipe/awesome-jobs-colombia
  - MauricioRobayo/trm-api
  - Mteheran/api-colombia
  - nequibc/colombia-holidays
  - john-guerra/navio
  - esbanarango/ember-model-validator
  - jdvelasq/cashflows
  - sjdonado/monocuco
  - ylecuyer/public-apis-colombia
  - joelibaceta/top-coders-colombia
  - camilomontoyau/bootcamp-hablemos-de-programacion
  - esbanarango/Competitive-Programming
  - DiegoRBaquero/node-fb-messenger
  - erikagtierrez/multiple-media-picker
  - fastapi/fastapi
  
display_name: Made in Colombia
created_by: andresayac
image: made-in-colombia.png
---
Open source projects built in or receiving significant contributions from Colombia :colombia:
