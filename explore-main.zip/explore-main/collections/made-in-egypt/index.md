---
items:
  - KL13NT/ally-reads
  - RobustaStudio/bkit
  - aliftype/amiri
  - Gue3bara/Cairo
  - logaretm/vee-validate
  - ahmadalfy/workflow
  - themsaid/wink
  - RobustaStudio/Resala
  - swvl/express-versioned-route
  - Ahmed-Ali/JSONExport
  - piscibus/notifly
  - gogearbox/gearbox
  - ahegazy/php-mvc-skeleton
  - aboul3la/Sublist3r
  - ShaftHQ/SHAFT_ENGINE
  - fawry-api/fawry
  - harryadel/AI-ML-Driven-Companies-In-Egypt
  - abdumostafa/awesome-in-arabic
  - hci-lab/PyQuran
  - DrWaleedAYousef/Teaching
  - amr3k/sveltegram
display_name: Made in Egypt
created_by: AN4553R
image: made-in-egypt.png
---
Open source projects built in or receiving significant contributions from Egypt 🇪🇬
