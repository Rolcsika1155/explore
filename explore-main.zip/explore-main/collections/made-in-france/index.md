---
items:
 - strapi/strapi
 - Qovery/engine
 - symfony/symfony
 - scikit-learn/scikit-learn
 - marmelab/react-admin
 - fzaninotto/Faker
 - huggingface
 - traefik
 - deezer/spleeter
 - algolia/places
 - ovh/cds
 - nuxt
 - api-platform/api-platform
 - lichess-org/lila
 - GitbookIO/gitbook
 - mui/material-ui
 - PrestaShop/PrestaShop
 - rlibre/x4js
 - QuivrHQ/quivr
display_name: Made in France
created_by: ferdi05
image: made-in-france.png
---
Open source projects built in or receiving significant contributions from France :fr:
