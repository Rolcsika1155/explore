---
items:
 - ariya/phantomjs
 - hyperjumptech/grule-rule-engine
 - kawalcovid19
 - usetania/tania-core
 - OpenSID
 - BaritoLog
 - xitorch/xitorch
 - mathdroid/covid-19-api
 - Kristories/awesome-guidelines
 - stisla/stisla
 - farizdotid/DAFTAR-API-LOKAL-INDONESIA
 - refactory-id/bootstrap-markdown
 - zuramai/mazer
 - mdmsoft/yii2-admin
display_name: Made in Indonesia
created_by: mabdh
image: made-in-indonesia.png
---
Open source projects built in or receiving significant contributions from Indonesia :indonesia:
