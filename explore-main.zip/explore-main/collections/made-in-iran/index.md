---
items:
 - jadijadi/bestoon
 - jadijadi/justforfun
 - mr-hashemi/mr-hashemi
 - pashmaklang/pashmak
 - roshan-research/moratab
 - PyFarsi/pyabr
 - jamedadi/yummy
 - roshan-research/hazm
 - rastikerdar/vazirmatn
 - mohebifar/made-in-iran
 - Hameds/APIs-made-in-Iran
 - Kiarash-Z/react-modern-calendar-datepicker
 - MahdiMajidzadeh/bootstrap-v4-rtl
 - imaNNeo/fl_chart
 - persian-tools/persian-tools
 - usablica/intro.js
 - jadijadi/linuxandlife
 - genyleap/Project-Template
 - HyperDbg/HyperDbg
 - GoFarsi/book
display_name: Made in Iran
created_by: Javad
image: made-in-iran.png
---

Iranian developer's list of open source projects :iran:
