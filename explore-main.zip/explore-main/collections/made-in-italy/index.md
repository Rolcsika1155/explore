---
items:
 - fastify/fastify
 - immuni-app/.github
 - italia/covid19-opendata-vaccini
 - middyjs/middy
 - nodejs/undici
 - elastic/elasticsearch-js
 - morrolinux/simple-ehm
 - micheleriva/coronablocker
 - HospitalRun/hospitalrun
 - histolab/histolab
 - strawberry-graphql/strawberry
 - notable/notable
 - espanso/espanso
 - eciavatta/caronte
 - Schroedinger-Hat/ImageGoNord
 - stoplightio/prism
 - ercole-io/ercole
 - Exifly/ApiVault
display_name: Made in Italy
created_by: thejoin95
image: made-in-italy.png
---
Open source projects built in or receiving significant contributions from Italy :it:
