---
items:
 - scdesktop/scdesktop
 - fnc12/sqlite_orm
 - aitemr/awesome-git-hooks
 - sozdik-kz/sozdik-android
 - mixdesign/AAShareBubbles
 - kekland/equinox
 - Slava/meteor-rethinkdb
 - SergeyMyssak/nextjs-sitemap
 - Slava/tern-meteor-sublime
 - binchik/SubscriptionPrompt
 - malikzh/NCANode
 - danchokobo/react-native-code-verification
 - yenbekbay/AYStepperView
 - ironsoul0/laddy
 - danabeknar/taza
 - yerlantemir/leetcoder

display_name: Made in Kazakhstan
created_by: snxx-lppxx
image: made-in-kazakhstan.png
---
Open source projects built in or receiving significant contributions from Kazakhstan :kazakhstan:

