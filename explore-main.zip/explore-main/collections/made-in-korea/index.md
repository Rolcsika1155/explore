---
items:
  - junegunn/fzf
  - junegunn/vim-plug
  - yunjey/pytorch-tutorial
  - nhn/tui.editor
  - posquit0/Awesome-CV
  - pinpoint-apm/pinpoint
  - summernote/summernote
  - kjw0612/awesome-deep-vision
  - line/armeria
  - gyoogle/tech-interview-for-developer
  - milooy/remote-or-flexible-work-company-in-korea
  - 738/awesome-sushi
  - konlpy/konlpy
  - javascript-tutorial/ko.javascript.info
  - ClintJang/awesome-swift-korean-lecture
  - SKTBrain/KoBERT
  - line/centraldogma
display_name: Made in Korea
created_by: ywroh
image: made-in-korea.png
---

Open source projects built in or receiving significant contributions from Korea :kr:
