---
items:
  - Humeira/made-in-Mauritius
  - Nayar/KDE-for-Mauritius
  - sjdvda/myt-usage-checker
  - mscraftsman/devcon2019
  - percymamedy/laravel-dev-booter
  - findbrok/php-watson-api-bridge
  - findbrok/laravel-personality-insights
  - LaraChimp/mango-repo
  - LaraChimp/pine-annotations
  - percymamedy/crafter
  - jcplaboratory/rashell
  - Abdur-rahmaanJ/greenberry
  - Abdur-rahmaanJ/honeybot
  - Abdur-rahmaanJ/meteomoris
  - vue-gapi/vue-gapi
  - reallyaditya/mauritius-speedtest
  - MrSunshyne/mauritius-fuel-prices
  - MrSunshyne/mauritius-dataset-electricity
  - MrSunshyne/mauritius-sea-cable
  - MrSunshyne/covid19-mauritius
  - MrSunshyne/mauritius-power-outages
display_name: Made in Mauritius
created_by: Naoero
image: made-in-mauritius.png
---
Open source projects built in or receiving significant contributions from Mauritius :mauritius:
