---
items:
  - geeksblabla/geeksblabla.com
  - mouadziani/laravel-mercanet
  - darija-open-dataset/dataset
  - ngMorocco/ngx-darija
  - redux-saga/redux-saga
  - Al-Fihriya-Academy/Machine-Learning
  - redouanelg/AppliedMathsInDarija
  - yjose/reactjs-popup
  - Edd13Mora/HackerNewsBdarija
  
  
display_name: Made in Morocco
created_by: leriaetnasta
image: made-in-morocco.png
---
Open source projects built in or receiving significant contributions from Morocco :morocco:
