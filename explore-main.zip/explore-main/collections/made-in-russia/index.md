---
items:
- https://github.com/ClickHouse/ClickHouse
- https://github.com/catboost/catboost
- https://github.com/nginx
- https://github.com/theKashey/awesome-made-by-russians

display_name: Made in Russia
created_by: toxblh
image: made-in-russia.png
---
Open source projects built in or receiving significant contributions from Russia 🇷🇺
