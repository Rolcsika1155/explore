---
items:
 - kin-lang/kin
 - vitest-dev/eslint-plugin-vitest
 - veritem/gcommit
 - divinrkz/swaggiffy
 - pacifiquem/awesome-go
 - Mutesa-Cedric/react-swift-reveal
 - pacifiquem/lepper
 - pacifiquem/lin
 - ndungtse/next13-progressbar
 - regisrex/json-base
 - regisrex/string-hunt
 - IVainqueur/auto-push
 - IVainqueur/package-mover
 - MuhireIghor/repo_initiator
  
display_name: Made in Rwanda
created_by: FADHILI-Josue
image: made-in-rwanda.png
---
Open source projects built in or receiving significant contributions from Rwanda :rwanda:
