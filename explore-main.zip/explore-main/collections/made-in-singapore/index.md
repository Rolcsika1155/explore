---
items:
 - datascapesg/red-cross-blood-stocks
display_name: Made In Singapore
created_by: chadlimjinjie
image: made-in-singapore.png
---
Open source projects built in or receiving significant contributions from Singapore :singapore: