---
items:
  - sharafdin/yonode
  - sharafdin/markdown-master
  - duraanali/luuqad
  - sharafdin/better-react-js-code-snippet-extension
  - hanad124/furqan-constructions
  - abdinasir-Tman/shaqo-sahal
  - WorkHubSo/WorkHubSo
  - JUST-4EVER/CAZA-MART
  - hanad124/graadkaabPlatform
  - miirshe/Al-caasima-Hospital-Management-System
  - dugsiiyeinc/native-skeleton
  - miirshe/doctor-appointment
  - ENG-CJ/exam-complaining-app
  - hanad124/clothing-e-commerce
  - miirshe/taskWave
  - miirshe/doctor-appointment_app
  - hanad124/sinay-petroleum-management_system
  - hanad124/apartment-mns
  - miirshe/webblogs
  - ENG-CJ/Food-Order-App-Server
  - kavi-kv/oraahyo_app
  - MoDev40/ai-bg-remover
  - ENG-CJ/Job-Finder-App
  - ENG-CJ/Freelancing-WebApp
  - aaqyaar/sooyaal-app
  - aaqyaar/ijaar-platform
  - AbdullahiKhalif/iskuxire-web-app
  - MoDev40/quizera
  - aaqyaar/ogaalkoob-app
  - aaqyaar/SimpleBank.API
  - aaqyaar/e-commerce-mern
  - aaqyaar/chatting-web-app
  - MoDev40/expense-tracker
  - MoDev40/budget-management
  
display_name: Made in Somalia
created_by: isasharafdin
image: made-in-somalia.png
---
Open source projects built in or receiving significant contributions from Somalia :somalia:
