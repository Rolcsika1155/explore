---
items:
 - voidcosmos/npkill
 - midudev/codi.link
 - microlinkhq/unavatar
 - svgdotjs/svg.js
 - microlinkhq/metascraper
 - react-toolbox/react-toolbox
 - midudev/covid-vacuna
 - franciscop/picnic
 - postcss/postcss
 - browserslist/browserslist
 - carloscuesta/gitmoji
 - penpot/penpot
 - taigaio/taiga-back
display_name: Made in Spain
created_by: eschiclers
image: made-in-spain.png
---

Open source projects built in or receiving significant contributions from Spain :es: 
