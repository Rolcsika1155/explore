---
items:
 - daenuprobst/covid19-cases-switzerland
 - OCA/l10n-switzerland
 - interactivethings/swiss-maps
 - SchweizerischeBundesbahnen/springboot-graceful-shutdown
 - LarsWerkman/HoloColorPicker

display_name: Made in Switzerland
created_by: Sigmale1000
image: made-in-switzerland.png
---
Open source projects built in or receiving significant contributions from Switzerland 🇨🇭 
