---
items:
 - ShareX/ShareX
 - furkandeveloper/EasyProfiler
 - isidentical/refactor
 - fatih/vim-go
 - ssg/streetcoder
 - ahmetb/kubectx
 - eser/laroux.js
 - f/vue-wait
 - joom/hezarfen
 - jbytecode/LinRegOutliers
 - jbytecode/JMcDM
 - jbytecode/rcaller
 - obss/sahi
 - passwall/passwall-server
 - passwall/passwall-extension
 - passwall/passwall-desktop
 - passwall/passwall-web
 - refinedev/refine
 - pankod/superplate
 - Huseyinnurbaki/mocktail
 - geziyor/geziyor
 - Trendyol/baklava
display_name: Made in Türkiye
created_by: kiliczsh
image: made-in-turkiye.png
---
Open source projects built in or receiving significant contributions from Türkiye :tr:
