---
items:
 - beetbox/beets
 - scottschiller/SoundManager2
 - CreateJS/SoundJS
 - musescore/MuseScore
 - tomahawk-player/tomahawk
 - cashmusic/platform
 - mopidy/mopidy
 - AudioKit/AudioKit
 - Soundnode/soundnode-app
 - gillesdemey/Cumulus
 - metabrainz/picard
 - overtone/overtone
 - sonic-pi-net/sonic-pi
 - swdotcom/swdc-vscode-musictime
 - hundredrabbits/Orca
 - 8bitbubsy/pt2-clone
 - 8bitbubsy/ft2-clone
 - mywave82/opencubicplayer
 - electronoora/komposter
 - BambooTracker/BambooTracker
 - theyamo/CheeseCutter
 - pete-gordon/hivelytracker
 - kometbomb/klystrack
 - schismtracker/schismtracker
 - chunkypixel/TIATracker
 - milkytracker/MilkyTracker
display_name: Music
created_by: jonrohan
---
Drop the code bass with these musically themed repositories.
