---
items:
 - jz222/caasy-nextjs-blog-template
 - pycoder2000/blog
 - timlrx/tailwind-nextjs-starter-blog
 - wutali/nextjs-netlify-blog-template
 - leerob/leerob.io
 - prismicio-community/nextjs-starter-prismic-blog
 - web3templates/stablo
 - Blazity/next-saas-starter
 - NextJSTemplates/startup-nextjs
 - statichunt/geeky-nextjs
 - statichunt/hydrogen-nextjs
 - themefisher/andromeda-light-nextjs
 - statichunt/techfeed-nextjs
 - devkiran/NextAPI
 - statichunt/hydrogen-nextjs
 - zeon-studio/nextplate
image: nextjs-blog-templates.png
display_name: Next.js Blog Template
created_by: officialrajdeepsingh
---

Start your blogging career using open-source pre-built templates with Next.js, Markdown, MDX, Tailwind CSS, React UI, etc.