---
items:
 - microsoft/nni
 - magda-io/magda
 - milvus-io/milvus
 - feast-dev/feast
 - tobegit3hub/advisor
 - optuna/optuna
 - h2oai/h2o-3
 - MLReef/mlreef
 - SeldonIO/alibi
 - guildai/guildai
 - mlflow/mlflow
 - VertaAI/modeldb
 - bentoml/BentoML 
 - pycaret/pycaret
 - whylabs/whylogs
 - argoproj/argo-workflows
 - zenml-io/zenml
 - aimhubio/aim
 - interpretml/interpret
 - mlrun/mlrun
 - microsoft/pai
 - allegroai/clearml
 - iterative/dvc
 - determined-ai/determined
 - InfuseAI/primehub
 - treeverse/lakeFS
 - activeloopai/deeplake
 - Netflix/metaflow
 - flyteorg/flyte
 - SchedMD/slurm
 - ray-project/ray
 - tensorflow/tensorboard
display_name: Open source MLOps
created_by: ManeSah
image: open-source-mlops.png
---
Open source projects to enhance your MLOps stack.
