---
items:
 - hashicorp/vault
 - pytorch/pytorch
 - https://nostalgic-css.github.io/NES.css/
 - vitessio/vitess
 - SpaceVim/SpaceVim
 - briangonzalez/rgbaster.js
 - Kong/kong
 - https://flutter.dev/
 - https://fishshell.com/
 - https://developer.nvidia.com/physx-sdk
display_name: Release Radar · December 2018
created_by: leereilly
---
Welcome to [the December 2018 edition of Release Radar](https://github.blog/2019-01-20-release-radar-december-2018/), where we share new and exciting releases from world-changing technologies to weekend side projects. Most importantly, they’re all projects shipped by you.

The GitHub community has been incredibly busy with exciting new releases over the holiday period. Here are a few highlights from December that caught our attention.
