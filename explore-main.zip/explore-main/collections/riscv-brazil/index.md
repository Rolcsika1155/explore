---
items:
 - darklife/darkriscv
 - zxmarcos/riscado-v
 - racerxdl/riskow
 - DuinOS/riscuinho
 - carlosedp/chiselv
display_name: Risc-V Cores Made in Brazil
created_by: carlosdelfino 
image: riscv-brazil.png
---

Projects related to RISC-V cores built or receiving significant contributions from Brazilians.
