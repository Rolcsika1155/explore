---
items:
- rails/rails
- sinatra/sinatra
- ruby-grape/grape
- hanami/hanami
- padrino/padrino-framework
display_name: Ruby Frameworks
created_by: m3xq
---
Frameworks that are designed to support the development of web applications including web services, web resources, and web APIs