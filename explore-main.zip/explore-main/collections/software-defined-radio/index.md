---
items:
 - gnuradio/gnuradio
 - gnuradio/volk
 - gqrx-sdr/gqrx
 - jgaeddert/liquid-dsp
 - miek/inspectrum
 - kpreid/shinysdr
 - RangeNetworks/openbts
 - srsran/srsRAN_4G
 - xmikos/qspectrumanalyzer
 - cjcliffe/CubicSDR
 - jopohl/urh
 - AlbrechtL/welle.io
 - merbanan/rtl_433
 - fsphil/hacktv
 - antirez/dump1090
 - https://www.youtube.com/embed/kWfU1G3Jq4w
display_name: Software Defined Radio
created_by: jbjonesjr
---
Interested in Software for Wireless Communications? This is the place.
