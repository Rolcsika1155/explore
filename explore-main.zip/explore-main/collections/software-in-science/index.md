---
items:
 - simbody/simbody
 - cms-sw/cmssw
 - ComputationalRadiationPhysics/picongpu
 - psas/av3-fc
 - astropy/astropy
 - dfm/emcee
 - cyverse/atmosphere
 - dib-lab/khmer
 - sympy/sympy
 - spack/spack
 - ipython/ipython
 - ropensci-archive/rplos
 - LaurentRDC/scikit-ued
 - sagemath/sage-archive-2023-02-01
 - gap-system/gap
 - Singular/Singular
 - flintlib/arb
 - broadinstitute/picard
 - markusschanta/awesome-jupyter
 - ropensci-archive/rplos
 - asreview/asreview
 - jupyterlab/jupyter-ai
 - voxel51/fiftyone
 - Future-Scholars/paperlib
 - pretzelai/pretzelai
 - iterative/dvc
 - git-lfs/git-lfs
display_name: Software in science
image: software-in-science.png
---
Scientists around the world are working together to solve some of the biggest questions in research.
