---
items:
 - uchicago-computation-workshop
 - UC-MACSS
 - UM-CSS
 - gesiscss
 - DS-BootCamp-DSI-Columbia/AY2017-2018-Summer-CSS
 - ben-aaron188/ltta_workshop
 - ribernhard/PS239T
 - msalganik/soc596_f2016
 - nealcaren/python-tutorials
 - jacobeisenstein/gt-css-class
 - jacobeisenstein/gt-nlp-class
 - eytan/www-15-tutorial
 - pablobarbera/POIR613
 - sf585978/cssReadingList
 - damian0604/bdaca/blob/master/book/bd-aca_book.pdf
 - vtraag/4TU-CSS
 - honeyAndSw/computational-social-science
 - 5harad/css
 - jaeyk/comp_thinking_social_science
 - jhofman/css2013
 - mac389/snappy
 - peterdalle/mediacommtools
 - dmasad/cssGradWorkshops
 - HerTeoh/computational_social_science
 - mobileink/lab.compss
 - sschauss/css
 - jongbinjung/css-python-workshop 
 - adamrpah/CSSMA
 - cbpuschmann/stm_ic2s2
 - ohexel/comsocsci
 - atkindel/css_activities
 - chandrasg/lexica
 - PsiPhiTheta/Computational-SocSci-Labs
 - maczokni/R-for-Criminologists
 - maczokni/crimemapping_textbook_bookdown
 - maczokni/r-socialsci
 - CJWorkbench
 - CullenBoldt/CSSproject
 - sagepublishing/Hogan-FSStDS-draft-chapters-2019
 - sagepublishing/Bernauer-DQTAwR-draft-chapters-2019
 
display_name: Teaching materials for computational social science
created_by: danielagduca
image: teaching-computational-social-science.png
---
Resources from and for teachers, trainers, lecturers and professors that are creating or running courses in computational social science, at any level.
