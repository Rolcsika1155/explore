---
items:
 - adobe/brackets
 - limetext/lime
 - textmate/textmate
 - neovim/neovim
 - overleaf/overleaf
 - slap-editor/slap
 - thomaswilburn/Caret
 - Komodo/KomodoEdit
 - leo-editor/leo-editor
 - syl20bnr/spacemacs
 - SpaceVim/SpaceVim
 - alm-tools/alm
 - atom/atom
 - LightTable/LightTable
 - zedapp/zed
 - microsoft/vscode
 - zyedidia/micro
 - neoedmund/neoeedit
 - mawww/kakoune
 - 0x7c13/Notepads
 - onivim/oni2
 - VSCodium/vscodium
 - JetBrains/intellij-community
 - emacs-mirror/emacs
 - rxi/lite
 - lite-xl/lite-xl
 - howl-editor/howl
 - notepad-plus-plus/notepad-plus-plus
 - XhmikosR/notepad2-mod
 - vim/vim
 - Alexey-T/CudaText
 - orbitalquark/textadept
 - apache/netbeans
 - adsr/mle
 - helix-editor/helix
 - lapce/lapce
 - zed-industries/zed
 - KDE/kate

display_name: Text editors
created_by: leereilly
image: text-editors.png
---
The text editor is a sacred tool for developers. Here's a showcase of some amazingly awesome open source editors.
