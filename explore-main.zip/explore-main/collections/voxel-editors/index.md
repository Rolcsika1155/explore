---
items:
 - woxels/Woxel
 - guillaumechereau/goxel
 - emilk/sproxel
 - grking/zoxel
 - Perkovec/Vuxel
 - GaidamakUA/Voxenko
 - gerardparareda/BlockyTracer
 - Bequen/GridEditor
 - honestabelink/stonevox3d
 - jval1972/DD_VOXEL
 - cubzh/cubzh
 - nimadez/voxel-builder
 - matpow2/voxie
 - rubenwardy/NodeBoxEditor
 - chrmoritz/Troxel
 - zakorgy/voxel-editor
 - simlu/voxelshop
 - vengi-voxel/vengi

display_name: Voxel Editors
---
Software to design and edit 3D voxel files, this list is only for standalone software and not extensions/plugins/addons to existing software. This list is NOT to be used to list software that is not designed to be Voxel First software - this means that if software has Voxel capabilities on the side and was not originally intended/designed to be used for Voxel editing then is not suitable for this list.
