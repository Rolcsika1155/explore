---
items:
 - gabrielecirulli/2048
 - ellisonleao/clumsy-bird
 - mozilla/BrowserQuest
 - AlexNisnevich/untrusted
 - doublespeakgames/adarkroom
 - Hextris/hextris
 - mrbid/Cubes2
 - mrbid/Snowboarder
 - mrbid/Snowling
 - mrbid/SNOWBALL2
 - mrbid/SpaceMiner
 - mrbid/FractalAttackOnlineLite
 - mrbid/CoinPusher
 - mrbid/TuxPusher
 - mrbid/SeriousShooter
 - mrbid/PoryDrive-2.0
 - mrbid/TuxScape
 - mrbid/Tuxocide
 - mrbid/AIGeneratedGame
 - mrbid/TuxVsDragon
display_name: Web games
created_by: leereilly
---
Have some fun with these open source games.
