---
display_name: action-adventure
topic: action-adventure
aliases: action-adventure-game
related: action-game, adventure-game, platformer, metroidvania, hack-and-slash, rpg, stealth-game, puzzle-game, open-world
short_description: A genre of video game that combines core elements from both the action game and adventure game genres.
wikipedia_url: https://en.wikipedia.org/wiki/Action-adventure_game
---
Action-adventure games are a genre of video games that combine elements from both the action game and adventure game genres. They typically feature a mix of combat, exploration, and puzzle-solving, often set in an open world or a nonlinear environment. Examples of popular action-adventure games include The Legend of Zelda, Uncharted, and Tomb Raider.
