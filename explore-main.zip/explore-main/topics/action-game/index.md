---
display_name: Action Game
topic: action-game
related: action-adventure-game, platformer, first-person-shooter, hack-and-slash, fighting-game
released: 1970
short_description: A genre of video game that emphasizes fast-paced gameplay and physical challenges.
wikipedia_url: https://en.wikipedia.org/wiki/Action_game
---
Action games are a genre of video game that focus on fast-paced gameplay and physical challenges. They often involve quick reflexes and hand-eye coordination, as well as problem-solving and strategy. Examples of action games include platformers, first-person shooters, hack-and-slash games, and fighting games. The action game genre has been around since the early 1970s and continues to be a popular and diverse category in the gaming industry.
