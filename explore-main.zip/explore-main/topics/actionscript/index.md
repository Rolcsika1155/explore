---
display_name: ActionScript
topic: actionscript
created_by: Gary Grossman
logo: actionscript.png
related: flash, adobe-flash, flash-player, adobe-air, air, as3, as2 
released: 1998
short_description: A object-oriented programming language used in Flash Player applications.
wikipedia_url: https://en.wikipedia.org/wiki/ActionScript
---

ActionScript is an object-oriented programming language created by Adobe. It is a implementation of ECMAScript used primarily in Flash Player applications. 
