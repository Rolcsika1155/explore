---
aliases: altvmp 
display_name: alt:V
logo: altv.png
short_description: A free alternative multiplayer platform for GTA:V.
topic: altv
url: https://altv.mp
---
A free alternative multiplayer client for GTA:V. Our client provides perfect synchronization on custom dedicated servers. Play with your friends and make your own gamemodes with JS, C# and much more.
