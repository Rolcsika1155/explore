---
aliases: android-application, android-app, android-development
created_by: Google
display_name: Android
github_url: https://github.com/android
logo: android.png
released: September 23, 2008
short_description: Android is an operating system built by Google designed for mobile
  devices.
topic: android
url: https://www.android.com/
wikipedia_url: https://en.wikipedia.org/wiki/Android_(operating_system)
---
Android was designed and built by Google in 2008. The operating system is written mainly in Java, with core components in C and C++. It is built on top of the Linux kernel, giving it incorporated security benefits.
