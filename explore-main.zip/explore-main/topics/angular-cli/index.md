---
display_name: Angular CLI
github_url: https://github.com/angular/angular-cli
logo: angular-cli.png
related: angular
released: May 9, 2017
short_description: Angular CLI lets you manage Angular applications from the command line.
topic: angular-cli
url: https://cli.angular.io/
---

The Angular CLI is a command-line interface tool that you use to initialize, develop, scaffold, and maintain Angular applications directly from a command shell.