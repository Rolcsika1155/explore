---
topic: animal-crossing
display_name: "Animal Crossing"
aliases: animal-crossing-new-horizons, new-horizons
related: nintendo, nintendo-switch
wikipedia_url: https://en.wikipedia.org/wiki/Animal_Crossing
short_description: "Animal Crossing is a video game series by Nintendo."
released: April 14, 2001
---
Animal Crossing is a video game series by Nintendo in which you play a human character who lives in a town populated by animals. Activities include fishing, digging up fossils, growing flowers, and catching bugs. The most recent game in the series is Animal Crossing: New Horizons on the Switch.
