---
display_name: Animation
short_description: Animation is the art of creating moving images.
topic: animation
wikipedia_url: https://en.wikipedia.org/wiki/Animation
---
Animation is a method in which figures are manipulated to appear as moving images.
