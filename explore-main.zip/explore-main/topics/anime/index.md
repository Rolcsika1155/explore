---
aliases: animes
display_name: Anime
short_description: Anime is hand-drawen & computer-generated animation produced in Japan.
topic: anime
wikipedia_url: https://en.wikipedia.org/wiki/Anime
---
Anime (Japanese: アニメ, IPA: [aɲime] (listen)) is hand-drawn and computer-generated animation often originating from Japan.
