---
created_by: Apple
display_name: Apple Music
logo: apple-music.png
related: apple, apple-music-api
short_description: Apple Music is a music streaming service developed by Apple.
released: June 30, 2015
url: https://www.apple.com/apple-music/
topic: apple-music
wikipedia_url: https://en.wikipedia.org/wiki/Apple_Music
---
Apple Music is a music streaming service developed by Apple. Subscribers of the service can stream over 90 million songs to their device on demand. The service offers curated playlists by music experts, recommendations tailored to a users music preference, and live 24-hour radio stations. Apple Music is accessible across a range of devices, including those not produced by Apple.