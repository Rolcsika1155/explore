---
created_by: Steve Jobs, Steve Wozniak, Ronald Wayne
display_name: Apple
logo: apple.png
related: swift, macos, ios
github_url: https://github.com/apple
short_description: Apple is a prominent hardware and software company.
released: April 1, 1976
url: https://www.apple.com/
topic: apple
wikipedia_url: https://en.wikipedia.org/wiki/Apple_Inc.
---
Apple Inc. designs, manufactures and markets smartphones, personal computers, tablets, wearables and accessories, and sells a variety of related services. The company’s products include iPhone, Mac, iPad, and Wearables, Home and Accessories.