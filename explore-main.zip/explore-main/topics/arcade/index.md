---
display_name: arcade
topic: arcade
aliases: arcade-game
related: mame, retro-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Arcade_game
---
An arcade game or coin-op game is a coin-operated entertainment machine typically installed in public businesses such as restaurants, bars and amusement arcades.