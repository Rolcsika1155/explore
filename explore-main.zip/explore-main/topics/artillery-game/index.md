---
display_name: artillery-game
topic: artillery-game
aliases: artillery
related: retro-game, arcade-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Artillery_game
---
Artillery games are early two or three-player (usually turn-based) video games involving tanks fighting each other in combat or similar.