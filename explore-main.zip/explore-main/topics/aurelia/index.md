---
created_by: Rob Eisenberg
display_name: aurelia
github_url: https://github.com/aurelia/aurelia
logo: aurelia.png
related: angular, react, vue, vuejs, inferno, mithril, ember, durandal, meteor, meteorjs
released: July 2016
short_description: A next generation JavaScript client framework that leverages simple conventions to empower your creativity.
topic: aurelia
url: https://aurelia.io
---
Aurelia is a next generation JavaScript client framework that leverages simple conventions to empower your creativity.
