---
created_by: Julien Danjou
display_name: AwesomeWM
github_url: https://github.com/awesomeWM
logo: awesomewm.png
released: September 18, 2007
short_description: AwesomeWM is a highly configurable, next generation framework window manager for X.
topic: awesomewm
url: https://awesomewm.org/
wikipedia_url: https://en.wikipedia.org/wiki/Awesome_(window_manager)
---
AwesomeWM is a dynamic window manager for the X Window System developed in the C and Lua programming languages. It aims to be extremely small and fast, yet extensively customizable. 
