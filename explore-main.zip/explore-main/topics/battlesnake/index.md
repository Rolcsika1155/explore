---
display_name: Battlesnake
github_url: https://github.com/BattlesnakeOfficial
logo: battlesnake.png
short_description: Battlesnake is a multi-player programming game played by developers all over the world.
topic: battlesnake
url: https://play.battlesnake.com/
---
Battlesnake is a collaborative programming challenge where developers create AI-driven programs that play the game Snake.  It provides opportunities for anyone to learn real-world skills and concepts in a safe, inclusive environment.