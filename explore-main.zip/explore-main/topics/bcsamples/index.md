---
aliases: bcdemos
created_by: Microsoft
display_name: Business Central Samples
logo: bcsamples.png
released: May 2023
short_description: Samples for Microsoft Dynamics 365 Business Central.
topic: bcsamples
url: https://dynamics.microsoft.com/business-central
---

# Microsoft Dynamics 365 Business Central

Business Central is a business management solution for small and mid-sized organizations that automates and streamlines business processes and helps you manage your business.

## bcsamples

All repositories listed below, contains the source code for publicly available samples, demos and tools.
