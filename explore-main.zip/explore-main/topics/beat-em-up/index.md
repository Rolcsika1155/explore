---
display_name: beat-em-up
topic: beat-em-up
aliases: beat-em-up-game, brawler, brawler-game
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Beat_%27em_up
---
A video game genre featuring hand-to-hand combat between the protagonist and a number of opponents.