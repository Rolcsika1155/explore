---
aliases: bds
created_by: Mojang
display_name: Bedrock Dedicated Server
github_url: https://github.com/Mojang
logo: bedrock-dedicated-server.png
related: minecraft, mc, minecraft-bedrock-edition, mcbe, minecraft-server, mcbe-server
released: 2018
short_description: BDS is a server hosting tool similar to the Java Edition server.
topic: bedrock-dedicated-server
url: https://www.minecraft.net/download/server/bedrock
---
Bedrock Dedicated Servers allow Minecraft players on Windows and Linux computers to set up their own server at home, or host their server using a cloud-based service.
