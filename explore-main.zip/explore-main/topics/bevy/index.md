---
created_by: Carter Anderson
display_name: Bevy
github_url: https://github.com/bevyengine/bevy
logo: bevy.png
related: rust, game-engine, gamedev
released: '2020'
short_description: A refreshingly simple data-driven game engine built in Rust.
topic: bevy
url: https://bevyengine.org/
---
Bevy is a refreshingly simple data-driven game engine built in Rust. It is free and open source forever!
