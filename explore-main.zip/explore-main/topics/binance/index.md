---
display_name: Binance
logo: binance.png
short_description: The largest cryptocurrency exchange in the world in terms of daily trading volume of cryptocurrencies.
topic: binance
related: binance-api
wikipedia_url: https://en.wikipedia.org/wiki/Binance
---
Binance is a cryptocurrency exchange which is the largest exchange in the world in terms of daily trading volume of cryptocurrencies. It was founded in 2017 and is registered in the Cayman Islands. Binance was founded by Changpeng Zhao (aka CZ), a developer who had previously created high frequency trading software. Binance was initially based in China, but later moved its headquarters out of China following the Chinese government's increasing regulation of cryptocurrency.
