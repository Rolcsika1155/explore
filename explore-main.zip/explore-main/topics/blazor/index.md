---
created_by: Microsoft
display_name: Blazor
github_url: https://github.com/dotnet/aspnetcore/tree/main/src/Components
logo: blazor.png
related: blazor-webassembly, blazor-server, dotnet, angular, svelte, vue, react
released: February 2018
short_description: Blazor is a free and open-source web framework that enables developers to create web apps using C# and HTML.
topic: blazor
url: https://dotnet.microsoft.com/en-us/apps/aspnet/web-apps/blazor
wikipedia_url: https://en.wikipedia.org/wiki/Blazor
---
Blazor is a .NET-based web application framework that allows developers to create single-page applications with C#, Razor, and HTML.
