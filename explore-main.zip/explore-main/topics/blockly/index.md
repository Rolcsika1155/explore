---
aliases: google-blockly
display_name: Blockly
short_description: A drag-n-drop library by Google.
topic: blockly
---
Blockly is a drag-n-drop library made by Google. It can define custom blocks, include plug-ins, convert blocks to real code, and more.
Many drag-n-drop code interfaces are based on it, most of which are educational.
