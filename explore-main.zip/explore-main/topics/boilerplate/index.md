---
aliases: boilerplate-code
display_name: Boilerplate
short_description: A boilerplate code is a piece of code that can be reused without significant changes.
topic: boilerplate
wikipedia_url: https://en.wikipedia.org/wiki/Boilerplate_code
---
A boilerplate code is a piece of code that can be reused without significant changes. When using a verbose language, the developer must write a lot only to accomplish minor functionality. Such code is called boilerplate.
