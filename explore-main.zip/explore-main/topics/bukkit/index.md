---
aliases: spigot, paper, papermc, craftbukkit
created_by: Nathan "Dinnerbone" Adams
display_name: Bukkit
logo: bukkit.png
released: December 22, 2010
short_description: Bukkit is a Minecraft server modification software. 
related: minecraft
github_url: https://github.com/Bukkit/Bukkit
topic: bukkit
url: https://dev.bukkit.org/
---
Bukkit is a Minecraft server modification software and API, and while the original project itself is stale, forks like PaperMC and Spigot are actively maintained, and most plugins and servers use some variant of Bukkit.
