---
aliases: bulmacss, bulma-css
created_by: Jeremy Thomas
display_name: Bulma
github_url: https://github.com/jgthms/bulma
logo: bulma.png
released: January 24, 2016
short_description: Bulma is a CSS framework.
topic: bulma
url: https://bulma.io
---
Bulma is a rising modern CSS framework that provides ready-to-use frontend components that can be easily combined to build responsive web interfaces.
