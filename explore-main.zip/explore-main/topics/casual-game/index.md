---
display_name: casual-game
topic: casual-game
aliases: casual
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Casual_game
---
A genre of video game that typically has simple rules shorter gameplay sessions, and less learned skill than others.