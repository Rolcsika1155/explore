---
display_name: CD (Disambiguation)
short_description: 'CD can either mean "continuous deployment" or "Continuous delivery".'
topic: cd
related: continuous-deployment, continuous-delivery, continuous-integration, cicd, devops
---
**CD**, within the context of [CI/CD](https://github.com/topics/cicd), can mean multiple things:
* [Continuous deployment](https://github.com/topics/continuous-deployment)
* [Continuous delivery](https://github.com/topics/continuous-delivery)
