---
aliases: chat-bot
display_name: Chat Bot
related: bot, telegram-bot
short_description: A chat bot is a computer program that simulates human conversation.
topic: chatbot
logo: chatbot.png
wikipedia_url: https://en.wikipedia.org/wiki/Chatbot
---
A software application used for an online chat via text or text-to-speech, instead of giving contact with a human.
