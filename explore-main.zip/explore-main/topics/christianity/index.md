---
display_name: Christianity
logo: christianity.png
related: religion, christian
short_description: Christianity is an Abrahamic monotheistic religion based on the life and teachings of Jesus of Nazareth.
topic: christianity
wikipedia_url: https://en.wikipedia.org/wiki/Christianity
---
Christianity is an Abrahamic monotheistic religion based on the life and teachings of Jesus of Nazareth. It is the world's largest religion, with about 2.5 billion followers.
