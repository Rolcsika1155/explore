---
aliases: cinnamon-desktop
created_by: Clément Lefèbvre
display_name: Cinnamon
github_url: https://github.com/linuxmint/cinnamon
logo: cinnamon.png
related: gtk, linuxmint, linux
released: December 20, 2011
short_description: Cinnamon is a desktop environment which combines a traditional desktop layout with modern graphical effects.
topic: cinnamon
url: https://projects.linuxmint.com/cinnamon/
wikipedia_url: https://en.wikipedia.org/wiki/Cinnamon_(desktop_environment)
---
Cinnamon is a free and open source desktop environment for Linux and other Unix-like operating systems, which was originally based off of GNOME 3, but follows traditional desktop metaphor conventions.
