---
display_name: Citizen science
short_description: Citizen science is a form of scientific research in which members of the public participate.
topic: citizen-science
wikipedia_url: https://en.wikipedia.org/wiki/Citizen_science
---

Citizen science is a form of scientific research in which members of the public participate. It is often used to describe scientific research conducted by amateur scientists, but it can also be used to describe scientific research conducted by professional scientists that involve members of the public.
