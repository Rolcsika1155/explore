---
display_name: client
short_description: Any computer hardware or software that requests access to a server.
topic: client
wikipedia_url: https://en.wikipedia.org/wiki/Client_(computing)
---
A client is a computer hardware or software that accesses a service made available by a server.
