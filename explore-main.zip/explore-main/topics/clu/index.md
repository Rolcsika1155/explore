---
created_by: Barbara Liskov et al.
display_name: CLU
released: 1975
short_description: CLU was the first implemented programming language to provide direct linguistic support for data abstraction.
topic: clu
url: https://pmg.csail.mit.edu/CLU.html
wikipedia_url: https://en.wikipedia.org/wiki/CLU_(programming_language)
---
CLU was the first implemented programming language to provide direct linguistic support for data abstraction.  CLU contains a number of other interesting and influential features, including checked exceptions, iterators, and parametric polymorphism.
