---
aliases: quality
display_name: Code quality
short_description: Automate your code review with style, quality, security, and test‑coverage checks when you need them.
topic: code-quality

---
Automate your code review with style, quality, security, and test‑coverage checks when you need them most. Code quality is intended to keep complexity down and runtime up.
