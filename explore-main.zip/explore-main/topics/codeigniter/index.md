---
aliases: code-igniter, codeigniter4, ci4
display_name: CodeIgniter
short_description: CodeIgniter is an open-source PHP rapid development web framework, for building dynamic web sites.
topic: codeigniter
related: mvc, hmvc, rapid-development, content-security-policy, owasp, routing, php-framework
wikipedia_url: https://en.wikipedia.org/wiki/CodeIgniter
github_url: https://github.com/codeigniter4
created_by: British Columbia Institute of Technology, EllisLab
released: February 28, 2006
logo: codeigniter.png
---
**CodeIgniter** is an open source software rapid development web framework, for use in building dynamic web sites with PHP.
