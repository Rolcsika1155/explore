---
display_name: collectible-card-game
topic: collectible-card-game
aliases: tcg, ccg, card-game, trading-card-game
related: pokemon-tcg, magic-tcg, pokemontcg, magictcg, magic-the-gathering
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Collectible_card_game
---
A strategic card game that that consists of specially designed sets of playing cards.