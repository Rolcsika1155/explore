---
display_name: combat-flight-simulator
topic: combat-flight-simulator
aliases: combat-flight-simulator-game
related: flight-simulator
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Combat_flight_simulation_game
---
Simulation video games used to simulate military aircraft and their operations.