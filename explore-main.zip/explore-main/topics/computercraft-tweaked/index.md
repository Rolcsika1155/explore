---
created_by: Jonathan Coates
display_name: "CC: Tweaked"
github_url: https://github.com/cc-tweaked/CC-Tweaked
url: https://tweaked.cc/
logo: computercraft-tweaked.png
related: computercraft,lua,minecraft,minecraft-mod
topic: computercraft-tweaked
released: November 15, 2017
short_description: "CC: Tweaked is a fork of ComputerCraft, adding programmable computers, turtles and more to Minecraft."
---
CC: Tweaked is a mod for [Minecraft](https://github.com/topics/minecraft) which adds programmable computers, turtles and more to the game. A fork of the much-beloved [ComputerCraft](https://github.com/topics/computercraft), it continues its legacy with better performance, stability, and a wealth of new features.
