---
created_by: Diego Rodriguez-Losada, Luis Martinez de Bartolome
display_name: Conan
github_url: https://github.com/conan-io/conan
url: https://conan.io/
logo: conan.png
related: package-manager,cpp,c,cplusplus,multi-platform,cmake
aliases: conanio
topic: conan
released: December 1, 2015
short_description: The open-source C/C++ package manager.
---
Conan, the C / C++ Package Manager for Developers. The open source, decentralized and multi-platform package manager to create and share all your native binaries.
