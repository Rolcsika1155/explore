---
display_name: Configuration
short_description: The arrangement of function details for a computer program.
topic: configuration
wikipedia_url: https://en.wikipedia.org/wiki/Computer_configuration
---
The arrangement of function details and information that is stored and used in a computer program.
