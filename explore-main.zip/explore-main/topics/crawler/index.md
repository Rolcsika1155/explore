---
display_name: Crawler
short_description: A computer program that gathers and categorizes information on the World Wide Web.
logo: crawler.png
topic: crawler
wikipedia_url: https://en.wikipedia.org/wiki/Web_crawler
---

A Web crawler, sometimes called a spider or spiderbot and often shortened to crawler, is an Internet bot that systematically browses the World Wide Web and that is typically operated by search engines for the purpose of Web indexing (web spidering).