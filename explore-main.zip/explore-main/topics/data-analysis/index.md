---
display_name: Data analysis
short_description: Data analysis is a process of inspecting, cleansing, transforming, and modeling data.
topic: data-analysis
wikipedia_url: https://en.wikipedia.org/wiki/Data_analysis
---

Data analysis is a process of inspecting, cleansing, transforming, and modeling data with the goal of discovering useful information, informing conclusions, and supporting decision-making.