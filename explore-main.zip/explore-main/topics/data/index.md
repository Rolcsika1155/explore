---
display_name: data
related: datum
short_description: Facts and statistics (numerical data) that may be analysed.
topic: data
wikipedia_url: https://en.wikipedia.org/wiki/Data
---
Individual facts, statistics, or items of information, often numeric. In a technical sense, data are a set of values of qualitative or quantitative variables about one or more persons or objects.
(https://en.wikipedia.org/w/index.php?title=Data&oldid=1093674723, released under CC BY-SA 3.0)
