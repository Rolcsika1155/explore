---
aliases: debian-linux, debianlinux
created_by: Ian Murdock
display_name: Debian
github_url: https://github.com/debian
logo: debian.png
related: linux, ubuntu
released: September 15, 1993
short_description: Debian is a Linux based operating system.
topic: debian
url: https://www.debian.org
wikipedia_url: https://en.wikipedia.org/wiki/Debian
---
Debian, also known as Debian Linux, is a GNU/Linux distribution composed of open source software, developed by the Debian Project.
