---
aliases: deeplearning, deep-learning-tutorial, deep-learning-algorithms, deep-learning-papers
display_name: Deep learning
short_description: Deep Learning is an artificial neural network composed of many
  layers.
topic: deep-learning
wikipedia_url: https://en.wikipedia.org/wiki/Deep_learning
---
Deep learning is an AI function and a subset of machine learning, used for processing large amounts of complex data. Deep learning can automatically create algorithms based on data patterns.
