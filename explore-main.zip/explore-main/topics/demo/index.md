---
aliases: demos
display_name: Demo
short_description: A example of a product or system.
topic: demo
wikipedia_url: https://en.wikipedia.org/wiki/Technology_demonstration
---
A rough example or otherwise incomplete version of a conceivable product or future system.