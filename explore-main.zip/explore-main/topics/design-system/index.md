---
display_name: Design system
short_description: A design system is a way to have modular and reusable CSS components as well as a separation of concerns.
topic: design-system
related: css, design-token, style-guide, css-framework, ui, smacss
wikipedia_url: https://en.wikipedia.org/wiki/Design_system
---
A **design system** is a way to have modular and reusable CSS components as well as a separation of concerns of designing and using this system, by, for examplr, using design tokens.
