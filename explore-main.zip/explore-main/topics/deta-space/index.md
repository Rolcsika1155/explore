---
display_name: Deta Space
github_url: https://github.com/deta/
logo: deta-space.png
short_description: '"Personal cloud" app marketplace and development/hosting platform.'
topic: deta-space
url: https://deta.space/
---
Deta Space allows users to develop apps and run their own private instances of apps, meaning "you'll have complete control over your apps and your data never leaves your own cloud".
