---
display_name: Developer experience
aliases: dx
short_description: Set of utilities, libraries or frameworks that help software engineers build productivity.
topic: developer-experience
---

Developer experience, also abbreviated as DX means a set of utilities, libraries or frameworks that help software engineers build productivity surrounding their projects. A good DX helps developers ship features faster and more reliably.
