---
aliases: discordapp
topic: discord
github_url: https://github.com/discord
display_name: Discord
logo: discord.png
short_description: Discord is a free voice, video, and text chat app for teens and adults ages 13 and up.
url: https://discord.com
wikipedia_url: https://en.wikipedia.org/wiki/Discord_(software)
---
Discord is a proprietary freeware voice-over-Internet Protocol (VoIP) application designed for video gaming communities, that specializes in text, image, video, and audio communication between users in a chat channel.
