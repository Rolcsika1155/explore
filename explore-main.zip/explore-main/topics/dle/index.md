---
aliases: dle12, dle13, datalife
display_name: Data Life Engine
logo: dle.png
released: January 30, 2004
short_description: Data Life Engine CMS written with PHP and MySQL.
topic: dle
url: https://dle-news.ru/
wikipedia_url: https://ru.wikipedia.org/wiki/DataLife_Engine
---
DataLife Engine is a multifunctional Content Management System. One of the most popular CMS projects in Russia.
