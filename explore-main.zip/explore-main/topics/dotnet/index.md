---
aliases: dotnet-core, dotnetcore, dot-net
created_by: Microsoft
display_name: ".NET"
github_url: https://github.com/dotnet
logo: dotnet.png
released: February 13, 2002
short_description: ".NET is a free, cross-platform, open source developer platform."
topic: dotnet
url: https://dotnet.microsoft.com
wikipedia_url: https://en.wikipedia.org/wiki/.NET_Framework
---
.NET is a free, cross-platform, open source developer platform for building many different types of applications.
