---
aliases: microsoft-edge, edge-browser
related: chrome, firefox, safari, opera, browser
created_by: Microsoft
display_name: Edge
logo: edge.png
released: April 29, 2015
short_description: Edge is a cross-platform web browser created and developed by Microsoft.
topic: edge
url: https://www.microsoft.com/edge
wikipedia_url: https://en.wikipedia.org/wiki/Microsoft_Edge
---

Microsoft Edge is a cross-platform web browser created and developed by Microsoft. First released for Windows 10 in 2015, for Android and iOS in 2017, for macOS in 2019, and for Linux in 2020, can replace Internet Explorer on Windows 7, Windows Server 2008 R2 and later versions.