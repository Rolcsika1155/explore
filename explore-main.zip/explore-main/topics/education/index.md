---
display_name: Education
short_description: The act or process of imparting or acquiring particular knowledge or skills, as for a profession.
topic: education
wikipedia_url: https://en.wikipedia.org/wiki/Education
---
Education is a purposeful activity directed at achieving certain aims, such as transmitting knowledge or fostering skills and character traits.
