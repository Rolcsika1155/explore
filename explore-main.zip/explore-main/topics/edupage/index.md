---
aliases: asc
display_name: EduPage
short_description: Everything from Teacher's agenda to Student's Homework.
topic: edupage
created_by: asc Applied Software Consultants, s.r.o.
related: school
url: https://www.edupage.org
---
EduPage is a cloud based school management system, electronic student assignment system and student grading system. It's used in more than 173 countries and +150k schools.
