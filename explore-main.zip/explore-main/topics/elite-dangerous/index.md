---
created_by: Frontier Developments
display_name: Elite Dangerous 
logo: elite-dangerous.png
released: December 16, 2014
short_description: Elite Dangerous is a space flight simulation game.
topic: elite-dangerous
related: elite-journal, eddiscovery, inara, eddn, edsm, eliteapi, frontier-api, eddi
url: https://www.elitedangerous.com/
wikipedia_url: https://en.wikipedia.org/wiki/Elite_Dangerous
---
Elite Dangerous is a space flight simulation game with open-ended, massively multiplayer gameplay. It is set in a realistic 1:1 scale open-world representation of the Milky Way galaxy. 
