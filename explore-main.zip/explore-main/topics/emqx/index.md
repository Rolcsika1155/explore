---
aliases: emq, emqtt
created_by: EMQ Technologies
display_name: EMQX
github_url: https://github.com/emqx
logo: emqx.png
released: January 8, 2015
short_description: EMQX is a scalable open source MQTT broker for IoT, IIoT, and connected vehicles.
topic: emqx
url: https://www.emqx.com/en
---
EMQX is a scalable and popular open source MQTT broker with a high performance that connects 100M+ IoT devices in 1 cluster at 1ms latency. 
