---
display_name: Ethereum Name Service (ENS)
logo: ens.png
released: May 4, 2017
short_description: ENS is a name service build on Ethereum.
topic: ens
related: ethereum, blockchain, cryptocurrency
url: https://ens.domains
github_url: https://github.com/ensdomains
---
ENS offers a decentralised way to address resources both on and off the blockchain using simple, human-readable names.
