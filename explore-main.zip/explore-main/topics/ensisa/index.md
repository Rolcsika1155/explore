---
display_name: ENSISA
logo: ensisa.png
short_description: ENSISA - École nationale supérieure d'ingénieurs Sud-Alsace.
topic: ensisa
url: https://www.ensisa.uha.fr
---
ENSISA is a french engineering school located in Mulhouse, France. Here are some projects made by students.
