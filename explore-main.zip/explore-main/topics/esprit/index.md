---
created_by: Tahar Ben Lakhdar
display_name: ESPRIT
logo: esprit.png
related: university
github_url: https://github.com/Esprit-UP-ASI
short_description: ESPRIT, is a private engineering school in Tunisia.
released: March 1, 2003
url: https://www.esprit.tn/
topic: esprit
wikipedia_url: https://en.wikipedia.org/wiki/ESPRIT_(School)
---
École supérieure privée d'ingénierie et de technologie (the Private Graduate School of Engineering and Technology) or ESPRIT is a private engineering school in Tunisia based in Ariana. ESPRIT also has a business school branch, the ESPRIT Business School.
Since 2020, it has been part of the Honoris United Universities group.
In 2021, Entreprises Magazine ranks ESPRIT, Tunisia’s first engineering school.
