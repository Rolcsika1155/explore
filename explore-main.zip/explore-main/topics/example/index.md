---
aliases: examples
display_name: Example
short_description: A representation of something.
topic: example
---
A particular instance of something that is a representative of a group, or an illustration of somethign that's been generally described.