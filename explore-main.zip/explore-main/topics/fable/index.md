---
created_by: Alfonso Garcia-Caro
display_name: Fable
github_url: https://github.com/fable-compiler
logo: fable.png
related: elmish, fsharp
released: March 2017
short_description: Fable is an F#-to-Javascript transpiler.
topic: fable
url: https://fable.io/
---

Fable is a popular transpiler for F# to Javascript that brings F# to the Javascript world with tight interop capabilities.
