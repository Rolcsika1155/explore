---
display_name: fantasy-game
topic: fantasy-game
related: fighting-fantasy, cyoa
short_description: A genre of video game.
---
A genre of game, where players assume the roles of characters and act out fantastical adventures.