---
display_name: fighting-game
topic: fighting-game
related: beat-em-up
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/Fighting_game
---
A video game genre based around close combat between a limited number of characters, in an arena of fixed size.