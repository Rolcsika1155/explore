---
aliases: first-robotics, firstrobotics
created_by: FIRST
display_name: FIRST
github_url: https://github.com/first
logo: first.png
short_description: For Inspiration and Recognition of Science and Technology.
topic: first
url: https://www.firstinspires.org
wikipedia_url: https://en.wikipedia.org/wiki/FIRST
---

For Inspiration and Recognition of Science and Technology (FIRST) is an international youth organization that operates the FIRST Robotics Competition, FIRST LEGO League, FIRST Lego League Jr., and FIRST Tech Challenge competitions. Founded by Dean Kamen and Woodie Flowers in 1989, its expressed goal is to develop ways to inspire students in engineering and technology fields. Its philosophy is expressed by the organization as coopertition and gracious professionalism. 
