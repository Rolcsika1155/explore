---
created_by: Armin Ronacher
display_name: Flask
github_url: https://github.com/pallets/flask
logo: flask.png
released: April 1, 2010
short_description: Flask is a web framework for Python based on the Werkzeug toolkit.
topic: flask
url: http://flask.pocoo.org/
wikipedia_url: https://en.wikipedia.org/wiki/Flask_(web_framework)
---
Flask is a web framework for Python, based on the Werkzeug toolkit.
