---
display_name: Flathub
short_description: Flathub is the place to get and distribute apps for all of desktop Linux.
github_url: https://github.com/flathub
logo: flathub.png
topic: flathub
url: https://flathub.org
related: flatpak, linux
---
Flathub is the place to get and distribute apps for all of desktop Linux. It is powered by Flatpak, allowing Flathub apps to run on almost any Linux distribution.
