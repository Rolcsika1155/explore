---
display_name: Flatpak
short_description: Linux application sandboxing and distribution framework.
github_url: https://github.com/flatpak
logo: flatpak.png
released: September 2015
topic: flatpak
url: https://flatpak.org
wikipedia_url: https://en.wikipedia.org/wiki/Flatpak
related: flathub, linux
---
Flatpak is a system for building, distributing, and running sandboxed desktop applications on Linux.
