---
aliases: fluent
display_name: Fluent Design System
short_description: Fluent Design is a design language developed by Microsoft.
topic: fluent-design
created_by: Microsoft
url: https://www.microsoft.com/design/fluent/
wikipedia_url: https://en.wikipedia.org/wiki/Fluent_Design_System
---
Fluent Design is a design language developed in 2017 by Microsoft and was first used in the Windows 10 Fall Creators Update.
