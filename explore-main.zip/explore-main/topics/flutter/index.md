---
display_name: Flutter
topic: flutter
github_url: https://github.com/flutter
logo: flutter.png
related: dart, flutter-plugin, flutter-apps
released: May 2017
short_description: Flutter is an open source mobile application development SDK created by Google.
url: https://flutter.dev/
wikipedia_url: https://en.wikipedia.org/wiki/Flutter_(software)
---
Flutter is an open source framework by Google for building beautiful, natively compiled applications for Android, iOS, web, Windows, Linux, macOS, and embedded devices, all from a single codebase.

