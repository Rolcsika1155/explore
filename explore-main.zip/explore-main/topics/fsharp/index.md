---
created_by: Don Syme
display_name: F#
github_url: https://github.com/fsharp
logo: fsharp.png
related: language, dotnet
released: May 2005
short_description: F# ("F sharp") is a functional programming language for .NET.
topic: fsharp
url: https://dotnet.microsoft.com/languages/fsharp
wikipedia_url: https://en.wikipedia.org/wiki/F_Sharp_(programming_language)
---
F# (pronounced "F sharp") is a cross-platform, open source, functional programming language for .NET. It also includes object-oriented and imperative programming.
