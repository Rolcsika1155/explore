---
aliases: game-dev, gamedev
display_name: Game Development
short_description: Game Development is the art of creating games and describes the design, development and release of a game.
topic: game-development
logo: game-development.png
wikipedia_url: https://en.wikipedia.org/wiki/Video_game_development
---
Video game developers take a designer's concepts and build them into a playable game for users. Video game developers, also known as games developers or video game programmers, write code for games for a variety of formats, such as PCs, consoles, web browsers and mobile phones.
