---
topic: game-jam
aliases: gamejam
display_name: Game Jam
related: hackathon, ludum-dare, global-game-jam, game-off, js13k
short_description: A game jam is a hackathon for creating video games.
wikipedia_url: https://en.wikipedia.org/wiki/Game_jam
---
Game Jams challenge people to create games within a short period of time (usually over a weekend, a week, or a month), and with certain constraints like limited color palettes, file sizes, and themes.
