---
aliases: gcj-02, bd09, bd09ll, bd09mc, bd-09ll, bd-09mc
display_name: GCJ-02
short_description: GCJ-02 and BD-09 are map obfuscation algorithms used in China.
topic: gcj02
wikipedia_url: https://en.wikipedia.org/wiki/Restrictions_on_geographic_data_in_China#GCJ-02
---
GCJ-02 and BD-09 are map obfuscation algorithms used in China; obfuscation is mandatory for all domestic online maps.
