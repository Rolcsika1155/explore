---
display_name: Genshin Impact
short_description: Genshin Impact is a role-playing game developed by miHoYo.
topic: genshin-impact
url: https://genshin.hoyoverse.com
wikipedia_url: https://en.wikipedia.org/wiki/Genshin_Impact
---
Genshin Impact is a cross-platform role-playing game developed by miHoYo.
