---
created_by: The Bearodactyl
display_name: Geode Mods
short_description: Geode is a modding platform/sdk for the game Geometry Dash.
topic: geode-mods
related: geometry-dash, geode-sdk, geometrydash, modding
url: https://geode-sdk.org
logo: geode-mods.png
---
A huge percentage, if not a majority of all bugs reported in GD mods are caused by hook conflicts, direct node tree access, and other mod incompatabilities. This is what Geode has been made to solve.
