---
display_name: Geometry Dash
short_description: Open source Projects relating to the Video Game 'Geometry Dash'.
topic: geometry-dash
logo: geometry-dash.png
wikipedia_url: https://en.wikipedia.org/wiki/Geometry_Dash
---
Open source Projects relating to the Video Game 'Geometry Dash'. Most projects communicate with the Game Servers.
