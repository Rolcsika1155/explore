---
created_by: GitHub
display_name: GitHub CLI extension
github_url: https://github.com/cli/cli
logo: gh-extension.png
released: September 16, 2020
short_description: Community extensions for the GitHub CLI.
topic: gh-extension
url: https://cli.github.com
---
GitHub CLI extensions are community-maintained repositories that, when installed locally, add extra functionality to `gh` commands.
