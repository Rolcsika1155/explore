---
created_by: National Security Agency
display_name: Ghidra
github_url: https://github.com/NationalSecurityAgency/ghidra
logo: ghidra.png
related: software-analysis, disassembler, reverse-engineering
released: March 5, 2019
short_description: Ghidra is a software reverse engineering (SRE) framework.
topic: ghidra
url: https://ghidra-sre.org/
wikipedia_url: https://en.wikipedia.org/wiki/Ghidra
---
Ghidra is a software reverse engineering (SRE) suite of tools developed by NSA's Research Directorate in support of the Cybersecurity mission.
