---
display_name: Giscus
short_description: A comment system powered by GitHub Discussions.
topic: giscus
github_url: https://github.com/giscus/giscus
url: https://giscus.app/
logo: giscus.png
---
Giscus is a website comments system powered by GitHub Discussions.
