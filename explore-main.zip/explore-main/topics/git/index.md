---
created_by: Linus Torvalds
display_name: Git
github_url: https://github.com/git
logo: git.png
released: April 7, 2005
short_description: Git is the most widely used version control system.
topic: git
url: https://git-scm.com/
wikipedia_url: https://en.wikipedia.org/wiki/Git
related: vcs, github, bitbucket, gitlab, gitops, gitflow, svn, mercurial, tfvc, dvcs
---
**Git** is the most widely used version control system, which allows for the tracking and managing of source code over time. It was designed for collaboration and built to be flexible, secure and efficient.
