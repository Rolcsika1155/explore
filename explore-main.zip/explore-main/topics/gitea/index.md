---
created_by: Lunny Xiao
display_name: Gitea
short_description: Git with a cup of tea.
github_url: https://github.com/go-gitea/gitea
logo: gitea.png
released: 17 October 2016
related: git, github, gitlab, gogs
topic: gitea
url: https://about.gitea.com
wikipedia_url: https://en.wikipedia.org/wiki/Gitea
---
Gitea is a all-in-one software development service, including Git hosting, code review, team collaboration, package registry and CI/CD