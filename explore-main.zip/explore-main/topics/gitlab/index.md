---
created_by: Dmitriy Zaporozhets, Sytse Sijbrandij
display_name: GitLab
logo: gitlab.png
related: github, bitbucket
released: October 8, 2011
short_description: GitLab is a single application that spans the entire software development lifecycle.
topic: gitlab
url: https://about.gitlab.com/
wikipedia_url: https://en.wikipedia.org/wiki/GitLab
---
GitLab is an open source software that combines the ability to develop, secure, and operate software in a single application.