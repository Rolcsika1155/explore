---
created_by: Gero Posmyk-Leinemann
display_name: Gitpod
github_url: https://github.com/gitpod-io/gitpod/
logo: gitpod.png
released: August 2018
short_description: an online service that provides disposable, ready-to-code development environments for GitHub projects.
topic: gitpod
url: https://www.gitpod.io
wikipedia_url: https://en.wikipedia.org/wiki/Gitpod
---
Gitpod is a container-based development platform that puts developer experience first. Gitpod provisions ready-to-code development environments in the cloud accessible through your browser and your local IDE.
