---
display_name: god-game
topic: god-game
aliases: artificial-life-game, artificial-life
short_description: A genre of video game.
wikipedia_url: https://en.wikipedia.org/wiki/God_game
---
A genre of video game allowing players to control the game on a large scale with divine and supernatural powers.