---
created_by: Joe Chen 
display_name: Gogs
short_description: A painless self-hosted Git service.
github_url: https://github.com/gogs/gogs
logo: gogs.png
released: 31 March 2014
related: git, github, gitlab, gitea
topic: gogs
url: https://gogs.io
---
Gogs is a simple, stable and extensible self-hosted Git service